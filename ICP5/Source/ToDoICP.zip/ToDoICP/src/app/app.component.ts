import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor() {
    setInterval(() => {this.today = Date.now(); }, 1);
  }
  today: number = Date.now();
  addedItems = [];
  todoItems = [];
  completedItems = [];

  // The countdown timer gets the specified date and time from when the timer should countdown
  countdownDate = new Date('September 26,2020 00:00:00').getTime();
  demo: any;
  days: any;
  hours: any;
  minutes: any;
  seconds: any;

  // tslint:disable-next-line:max-line-length
  // The present time is obtained, subtracted from the specified date and time and the resulting time is converted into days,hours,minutes and seconds.
  x = setInterval( () => {
    const now = new Date().getTime();
    const distance = this.countdownDate - now;
    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor(distance % (1000 * 60 * 60 * 24) / (1000 * 60 * 60));
    const minutes = Math.floor(distance % (1000 * 60 * 60) / (1000 * 60));
    const seconds = Math.floor(distance % (1000 * 60) / 1000);

    // The result is stored in the variables and displayed using elements in html page
    this.demo = 'Time for weekend to start: ' + days + 'd' + hours + 'h' + minutes + 'm' + seconds + 's';
    this.days = days;
    this.hours = hours;
    this.minutes = minutes;
    this.seconds = seconds;
  });


  // Code to push new item
  // Here we check if an item already exits in the list, if not, it is added to tasks in progress table, else an alert is shown.
  submitNewItem(newTodoLabel, priorityFromUser) {
    const index = this.addedItems.indexOf(newTodoLabel);
    if (index !== -1) {
      alert('Item already exists.');
    } else {
      const newTodo = {
        label: newTodoLabel,
        done: false,
        priority: priorityFromUser
      };

      this.todoItems.push(newTodo);
      this.addedItems.push(newTodoLabel);
    }
  }
  // Code to delete item
  // The items other than the seleted one for deletion is filtered out from the original list and updated in the original list.
  deleteItem(todo) {
    this.todoItems = this.todoItems.filter( t => t.label !== todo.label);
  }

  // Code to delete item
  // The items other than the seleted one for deletion is filtered out from the original list and updated in the original list.
  deleteItemfromCompleted(todo) {
    this.completedItems = this.completedItems.filter( t => t.label !== todo.label);
  }

  // Code to complete item
  // The items chosen for completion is updated with true for completed_flag and pushed to completed table.
  completeItem(todo) {
    const index = this.todoItems.indexOf(todo);
      this.todoItems.splice(index, 1);
      todo.done = true;
      this.completedItems.push(todo);
  }

  newTaskFromCompleted(newFromComp) {
    const index = this.completedItems.indexOf(newFromComp);
    this.completedItems.splice(index, 1);
    newFromComp.done = false;
    this.todoItems.push(newFromComp);
    this.addedItems.push(newFromComp);
  }

}
