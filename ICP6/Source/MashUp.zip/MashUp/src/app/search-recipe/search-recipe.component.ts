import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-search-recipe',
  templateUrl: './search-recipe.component.html',
  styleUrls: ['./search-recipe.component.css']
})
export class SearchRecipeComponent implements OnInit {
  @ViewChild('recipe') recipes: ElementRef;
  @ViewChild('place') places: ElementRef;
  recipeValue: any;
  placeValue: any;
  venueList = [];
  recipeList = [];
  currentLat: any;
  currentLong: any;
  geolocationPosition: any;
  collection: any;
  image: any;
  // The URL for foursqaure API
  // tslint:disable-next-line:max-line-length
  URL = 'https://api.foursquare.com/v2/venues/explore?client_id=D3XGGXCHEIPGI1J1ETHAY5AJSRJQNBPDKQJOEIJPZLLXE4F3&client_secret=PBUIEF40N3EGI0U5PVPMB2BH5BKWG4WBUNBJKVQN11OVKIS1&v=20180323&limit=5&near=';

  constructor(private _http: HttpClient) {
  }

  /**
   * Obtain the list of venues and recipes for the input
   */
  getVenues() {
    this.recipeValue = this.recipes.nativeElement.value;
    this.placeValue = this.places.nativeElement.value;

    // The following If statement checks if the recipe name is available, if so, then the recipe is searched for returened
    if (this.recipeValue !== null) {
      console.log('https://api.edamam.com/search?q=' + this.recipeValue +
        '&app_id=f05089e9&app_key=b4e692a253dbbed58957da50e6bc305c');
      this._http.get('https://api.edamam.com/search?q=' + this.recipeValue +
        '&app_id=f05089e9&app_key=b4e692a253dbbed58957da50e6bc305c').
      subscribe(respReceipe => {
        this.recipeList = respReceipe['hits'];
      }, error => {});

    }
    // The following condition checks if the place and recipe values both are given, then it redirects the search to fourman API
    if (this.placeValue != null && this.placeValue !== '' && this.recipeValue != null && this.recipeValue !== '') {
      this._http.get(this.URL + this.placeValue + '&query=' + this.recipeValue).
      subscribe(respRestuarant => {
        this.collection = respRestuarant['response'].groups[0].items;
        this.venueList = this.collection.map(e => e.venue);
      }, error => {});
      console.log(this.URL + this.placeValue + '&query=' + this.recipeValue);
    }
  }

  ngOnInit(): void {
  }
}
