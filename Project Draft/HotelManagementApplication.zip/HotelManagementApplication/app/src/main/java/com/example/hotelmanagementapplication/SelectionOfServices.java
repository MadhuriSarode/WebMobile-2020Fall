package com.example.hotelmanagementapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SelectionOfServices extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection_of_services);

        String[] myArray = {"Book Suite","Accessability","View by map"};
        List<String> fixedLenghtList = Arrays.asList(myArray);

//create object of listview holding all the locations list
        ListView listView=(ListView)findViewById(R.id.listOfServices);

//create ArrayList of String
        final ArrayList<String> arrayList=new ArrayList<String>(fixedLenghtList);

//Create array Adapter and fill in the data in it, of the location list
        ArrayAdapter arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,arrayList);

//assign adapter to listview
        listView.setAdapter(arrayAdapter);

//add listener to listview

        Toast.makeText(SelectionOfServices.this,"Click on any servies",Toast.LENGTH_SHORT).show();

        //Displaying the list of locations of quakes along with the link attached to it
        //which directs the user to view more details.
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String str = "clicked item:" + i + " " + arrayList.get(i) + " Following the  link for more details";
                Snackbar.make(view, str, Snackbar.LENGTH_SHORT).show();


                if(i==0)
                {
                    Snackbar.make(view, "Moving onto booking a suite", Snackbar.LENGTH_SHORT).show();
                }

                /*
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
                    startActivity(browserIntent);
                    */

            }
        });




    }
}